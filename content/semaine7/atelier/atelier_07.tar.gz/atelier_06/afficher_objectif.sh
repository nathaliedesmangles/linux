if [ "$1" = "" ];
then
    echo "usage: sh $0 NUMERO_EXERCICE"
    exit
fi

quitter_sur_erreur(){
    echo ""
    echo "[ERREUR]" $1
    echo ""
    exit
}

numero_exercice=$1

fichier_enonce=.enonces.txt
test -f $fichier_enonce || quitter_sur_erreur "aucun fichier énoncé"

enonce_exercice=$(cat $fichier_enonce | grep $numero_exercice | head -n1)
test "$enonce_exercice" != "" || quitter_sur_erreur "aucun énoncé"

cible=$(echo $enonce_exercice | cut -d" " -f2)
copie=.$(basename $cible).$numero_exercice
corrige=$(dirname $cible)/$copie.corrige

meld $cible $corrige
