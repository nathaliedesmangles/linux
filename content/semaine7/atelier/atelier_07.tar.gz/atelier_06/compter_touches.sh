# XXX: doit être appeler sans sudo, p.ex
#
# $ sh atelier_vim.sh 01
#
# demandera mot de passe au besoin

if [ "$1" = "" -o "$2" = "" ];
then
    echo "usage: sh $0 cible copie {debug}"
    exit
fi

log_brut=.brut.log
log_touches=.touches.log
logkeys=/usr/local/bin/logkeys
cible=$1
copie=$2
debug=$3

numero_clavier=$(ls /dev/input/by-path/* | grep kbd | while read i; do realpath $i; done | sed "s/.*event//" | sort -n | head -n1)
clavier="event$numero_clavier"

# quitter si on ne peut être sudo
sudo echo "" || exit

test -f $log_brut && sudo rm $log_brut

sudo $logkeys --start --output=$log_brut --device=/dev/input/$clavier
vim $copie
sudo $logkeys --kill


# une nouvelle ligne pour chaque <Enter>
nombre_de_lignes=$(sudo cat $log_brut | grep -o ">.*$" | wc -l)
test "$nombre_de_lignes" != "" || nombre_de_lignes=1
nombre_de_touches_entree=$(($nombre_de_lignes - 1))
test $nombre_de_touches_entree -gt 0 || nombre_de_touches_entree=0

touches_brutes=$(sudo cat $log_brut | grep -o ">.*$" | egrep -o "> (\S)+$" | cut -d" " -f2 | tr -d "\n")


if [ "$debug" != "" ];
then
    echo $touches_brutes
fi

nombre_repetitions=$(echo 0 $(echo $touches_brutes | egrep -o "<#+[^>]*>" | sed "s/<#//g" | sed "s/>//") | tr '\n' ' ' | sed "aquit" | bc)
touches_sans_repetitions=$(echo $touches_brutes | sed "s/<#+[^>]*>//g")

# les modificateurs ne comptent pas: <LCtrl><LAlt><LShft><AltGr><RCtrl><RShft><RShft><RShft>
touches_sans_modificateurs=$(echo $touches_sans_repetitions | sed "s/\(<LCtrl>\|<LAlt>\|<LShft>\|<AltGr>\|<RCtrl>\|<RShft>\|<RShft>\|<RShft>\)//g")

# <Esc>, <CpsLk>, <Left>, etc. comptent pour 1
touches_simples=$(echo $touches_sans_modificateurs | sed "s/<[^<>]*>/M/g")

# XXX: echo -n sinon \n compte!
# XXX: sed "s/./X/g" parce que wc -c compte les octets (donc 2 pour certains caractères utf8)
nombre_touches_simples=$(echo -n $touches_simples | sed "s/./X/g" | wc -c)


if [ "$debug" != "" ];
then
    echo $nombre_de_touches_entree + $nombre_repetitions + $nombre_touches_simples
fi

nombre_touches=$(echo $nombre_de_touches_entree + $nombre_repetitions + $nombre_touches_simples | bc)

echo $nombre_touches > $log_touches
