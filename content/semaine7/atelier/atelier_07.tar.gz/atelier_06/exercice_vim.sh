# XXX: doit être appeler sans sudo, p.ex
#
# $ sh atelier_vim.sh 01
#
# demandera mot de passe au besoin

if [ "$1" = "" ];
then
    echo "usage: sh $0 NUMERO_EXERCICE"
    exit
fi

quitter_sur_erreur(){
    echo ""
    echo "[ERREUR]" $1
    echo ""
    exit
}


log_brut=.brut.log
log_touches=.touches.log

numero_exercice=$1

fichier_enonce=.enonces.txt
test -f $fichier_enonce || quitter_sur_erreur "aucun fichier énoncé"

enonce_exercice=$(cat $fichier_enonce | grep $numero_exercice | head -n1)
test "$enonce_exercice" != "" || quitter_sur_erreur "aucun énoncé"

cible=$(echo $enonce_exercice | cut -d" " -f2)
avec_curseur=$(echo $enonce_exercice | cut -d" " -f3)

copie=.$(basename $cible).$numero_exercice
corrige=$(dirname $cible)/$copie.corrige
viminfo=$(dirname $cible)/$copie.viminfo
touches_corrige=$(dirname $cible)/$copie.touches

#  placer le curseur au besoin
#  sinon effacer ~/.viminfo
if [ "$avec_curseur" = "avec_curseur" ];
then
    # modifier .viminfo pour s'appliquer à la copie
    cat $viminfo  | sed "s,$cible,$copie,"  > ~/.viminfo

    # TMP: ma machine
    # cat $viminfo  | sed "s*~/*~/montmorency/cours/zc4/ateliers/06/*g" | sed "s,$cible,$copie,"  > ~/.viminfo
else
    rm ~/.viminfo
fi

cp $cible $copie
chmod 666 $copie

sh compter_touches.sh $cible $copie


terminer(){
    echo $1
    sudo rm $log_brut
    rm $log_touches
    rm $copie
    echo ""
    exit
}


nb_touches_usager=$(cat $log_touches)
nb_touches_min=$(cat $touches_corrige | cut -d" " -f1)
nb_touches_max=$(cat $touches_corrige | cut -d" " -f2)

test "$nb_touches_min" = "" && quitter_sur_erreur "nb_touches_min inconnu"
test "$nb_touches_max" = "" && quitter_sur_erreur "nb_touches_max inconnu"

test $nb_touches_min -eq $nb_touches_max && quitter_sur_erreur "nb_touches_min == nb_touches_max"

# afficher si réussi
diff $copie $corrige 1>/dev/null 2>/dev/null 
if [ $? -eq 0 ];
then
    echo "* Modification réussie en $nb_touches_usager touches"
else
    echo "* Modification échouée ($nb_touches_usager touches)"
    echo ""
    diff $corrige $copie
    terminer
fi
# afficher nombred de touches

echo ""

if [ $nb_touches_usager -le $nb_touches_max ];
then
    echo "* Exercice réussi"
else
    echo "* Exercice échoué... trop de touches"
fi

terminer
